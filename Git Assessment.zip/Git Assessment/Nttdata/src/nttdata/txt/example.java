package nttdata.txt;

public class example {

public static void main(String [] args)
	
{
	System.out.println("Hello, this is git tutorial");
	
}

}
s